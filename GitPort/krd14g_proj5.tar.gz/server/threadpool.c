/**
 * threadpool.c
 *
 * This file will contain your implementation of a threadpool.
 */
/*
-- NOTES -- :
pthread_exit() : will exit the thread that calls it. Main thread will terminate
and spawned threads will continue to execute. Used if main is used strictly to 
spawn threads.

pthread_join() : will suspend execution of the thread that has called it unless
the target thread terminates. Useful in cases when you want to wait for thread/s
to terminate before further processing in main thread

int pthread_mutex_destroy(pthread_mutex_t *mutex) : shall destroy the mutex object
referenced by mutex;the mutex object becomes, in effect, uninitialized. An 
implementation may cause pthread_mutex_destroy() to set the object refenced 
by mutex to an invalid value. ** It shall be safe to destroy an initialized
mutex that is unlocked. Attempting to destroy a locked mutex results in 
undefined behavior ** 

int pthread_mutex_init(pthread_mutex_t *restrict mutex,const pthread_mutexattr_t 
*restrict attr) : destroyed mutex object can be reinitialized using 
pthread_mutex_init() 
    *** If destroy or init are successful, 0's are returned ***

int pthread_mutex_lock(pthread_mutex_t *mutex) : Mutex object referenced will be 
locked. If the mutex is alread locked, the calling thread shall block until the 
mutex becomes available. Function shall return with the mutex object referenced 
by mutex in the locked state with the calling thread as its owner.
	*** If mutex type is PTHREAD_MUTEX_NORMAL : deadlock detection shall not
be provided. Attempting to relock the mutex causes deadlock. If a thread attempts
to unlock a mutex that it has not locked or a mutex which is unlocked, undefined
behavior results.
	*** If mutex type is PTHREAD_MUTEX_ERRORCHECK : then error checking shall
be provided. If a thread attempts to reclock a mutex that it has already locked, an
error shall be returned. If a thread attempts to unlock a mutex that it has not 
locked or a mutex which is unlocked, an error is returned.
	*** PTHREAD_MUTEX_RECURSIVE : then the mutex shall maintain the concept
of a lock count. When a thread successfully acqquires a mutex for the first time,
the lock count shall be set to one. Everytime a thread relocks this mutex, the 
lock count shall be incremented by one. Each time the thread unlocks the mutex, 
the lock count shall be decremented by one. When the lock count reaches zero, the
mutex shall become available for other threads to acquire. If a thread attempts to
unlocked a mutex that it has not locked or a mutex which is unlocked, an error is 
returned. 
	*** PTHREAD_MUTEX_DEFAULT, attempting to recursively lock the mutex results
in undefined behavior. Attempting to unlock the mutex if it was not locked by the
calling thread results in undefined behavior. Attempting to unlock the mutex if it
is not locked results in undefined behavior. 

int pthread_mutex_trylock(pthread_mutex_t *mutex) : function shall be equivalent
to pthread_mutex_lock(),except that if the mutex object referenced by mutex is 
currently locked (by any thread, including the current thread), the call shall 
return immediately. If the mutex type is PTHREAD_MUTEX_RECURSIVE and the mutex is 
currently owned by the calling thread, the mutex lock count shall be incremented 
by one and the pthread_mutex_trylock() function shall immediately return success.

int pthread_mutex_unlock(pthread_mutex_t *mutex) : function shall release the 
mutex object referenced by mutex.The manner in which a mutex is released is 
dependent upon the mutex's type attribute. If there are threads blocked on the 
mutex object referenced by mutex when pthread_mutex_unlock() is called, resulting 
in the mutex becoming available, the scheduling policy shall determine which 
thread shall acquire the mutex.
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#include "threadpool.h"

struct _node;
struct _queue;
typedef struct _node *nPtr;

struct _node
{
	void(*fnc)(void*);
	void *arg;
	nPtr next;
};

struct _queue
{
	int q_size;
	nPtr front;
	nPtr back;
};


nPtr dequeue(struct _queue *q)
{
	nPtr temp = (struct _node*) malloc(sizeof(struct _node));
	if(queue_empty(q) != 1)
	{
		temp = q->front;
		if(q->front == q->back)
		{
			q->front = NULL;
			q->back = NULL;
			return temp;
		}
		q->front = temp->next;
		return temp;
	}
}
void init_queue(struct _queue *q)
{
	//q = (struct _queue*) malloc(sizeof(struct _queue));
	q->front = NULL;
	q->back = NULL;
}
int queue_empty(struct _queue *q)
{
	if(q->front == NULL)
		return 1;
	else
		return -1;
}

void enqueue(struct _queue *q, struct _node *n)
{
	//struct _node *temp;
	//temp = n;
//	temp->next = NULL;
	q->q_size = q->q_size +1;
	if(queue_empty(q) == 1)
	{
		q->front = n;
		q->back = n;
		return;
	}
	q->back->next = n;
	q->back = n;
}
// _threadpool is the internal threadpool structure that is
// cast to type "threadpool" before it given out to callers
typedef struct _threadpool_st {
	pthread_mutex_t lock; // Mutex Lock
	pthread_cond_t cond;
	int num_thread; // Number of threads 
	pthread_t  *tid; // Array of threads
	struct _queue *tq; // Task Queue 
	int flag; 
// you should fill in this structure with whatever you need
} _threadpool;

void* thread_main(void* arguments)
{
	_threadpool *pool =(_threadpool*) arguments;
	while(1)
	{
		pthread_mutex_lock(&pool->lock);
		if((queue_empty(pool->tq) == 1) && (pool->flag != 1))
		{
			pthread_cond_wait(&pool->cond,&pool->lock);
		}
		if(pool->flag == 1)
		{
			pthread_mutex_unlock(&pool->lock);
			break;
		}
	nPtr temp = (struct _node*) malloc(sizeof(struct _node));
	temp = dequeue(pool->tq);
	pthread_mutex_unlock(&pool->lock);
	(temp->fnc)(temp->arg);
	free(temp);
//	printf("\nnum in dequeue -> %d\n",temp->num);				
	}
//	pool = (_threadpool*)malloc(sizeof(arguments));
//	pool = arguments;
//	printf("Dildos \%d",pool->num_thread);// %d", pool->num_thread);
	//pthread_exit(NULL);
	//free(pool);
	return NULL;
}
threadpool create_threadpool(int num_threads_in_pool) {
  _threadpool *pool;
  /*nPtr test = (struct _node*) malloc(sizeof(struct _node));
  nPtr current = (struct _node*) malloc(sizeof(struct _node));
  test->num = 1;
  test1->num = 2;*/
 // sanity check the argument
  if ((num_threads_in_pool <= 0) || (num_threads_in_pool > MAXT_IN_POOL))
    return NULL;
  pool = (_threadpool  *) malloc(sizeof(_threadpool));
  
  if (pool == NULL) {
    fprintf(stderr, "Out of memory creating a new threadpool!\n");
    return NULL;
  }
  pool->tid =  malloc(sizeof(pthread_t) * num_threads_in_pool);
  pool->num_thread = num_threads_in_pool;
//  pool->lock = PTHREAD_MUTEX_INITIALIZER;
//  pool->cond = PTHREAD_COND_INITIALIZER;

  // add your code here to initialize the newly created threadpool
  pool->tq = (struct _queue*) malloc(sizeof(struct _queue));
  int i;
  for(i = 0; i < num_threads_in_pool;i++)
  {
	pthread_create(&(pool->tid[i]),NULL,thread_main,pool);
//	pthread_create(&pool,NULL,&thread_main,NULL);//(void*)&pool);
//	thread_init(pool, &pool->tid[i],i);
  //	if(THPOOL_DEBUG)
//		print("THPOOL_DEDUG: Created thread %d in pool \n",i);
  }
  init_queue(pool->tq);
  pool->flag = 0;
  pool->tq->q_size = 0;
  /*if(queue_empty(pool->tq)==1)
        printf("\nQueue is empty test");
  test->next = NULL;
  enqueue(pool->tq,test);
  if(queue_empty(pool->tq)==-1)
        printf("\nQueue is no longer empty");
  enqueue(pool->tq,test1);
  current = pool->tq->front;
  while(current !=NULL)
  {
        printf("Num %d\n",current->num);
        current = current->next;
  }*/
  if(pthread_mutex_init(&pool->lock,NULL))
 	return NULL;
  if(pthread_cond_init(&pool->cond,NULL))
	return NULL;
//  free(pool->tq);
  return (threadpool) pool;
}


void dispatch(threadpool from_me, dispatch_fn dispatch_to_here,
	      void *arg) {
  _threadpool *pool = (_threadpool *) from_me;
 // struct _node *temp;
  nPtr temp = (struct _node*) malloc(sizeof(struct _node));
  temp->arg = arg;
  temp->fnc = dispatch_to_here;
  temp->next = NULL;
  pthread_mutex_lock(&pool->lock);
  enqueue(pool->tq,temp);
  pthread_cond_signal(&pool->cond);//,&pool->lock);
  pthread_mutex_unlock(&pool->lock);
  // add your code here to dispatch a thread
}

void destroy_threadpool(threadpool destroyme) {
  _threadpool *pool = (_threadpool *) destroyme;
  pthread_mutex_lock(&pool->lock);
  
	pool->flag = 1;
	pthread_cond_broadcast(&pool->cond);
	pthread_mutex_unlock(&pool->lock);
  
  int i;
  for(i = 0;i< pool->num_thread; i++)
	(void) pthread_join(pool->tid[i],NULL);
  
  pthread_mutex_destroy(&pool->lock);
  pthread_cond_destroy(&pool->cond);
  free(pool); 
// add your code here to kill a threadpool
}

