Kristopher Doidge
COP4610 
Project 5
11/28/2016

	The structure of my threadpool contains a self made Queue, Mutex Lock, thread Condition variable, array of Thread ID's, number of flags, and shutdown booleans.The Queue was made by using a simply linked list that contained 2
nodes, the Front Node and Back Node. These nodes are a structure that contains a pointer to the next block of data in our list, along with the data that is passed from dispatch. Similar to how the Queue class works in C++ and 
Python, my implementation includes enqueue, dequeue, list_empty, and init_queue. 
	The critical sections in my code exist in functions thread_main,dispatch, and destroy_threadpool. In thread_main, we need to have the critical section for each thread that is being created. What this does is creates a baton
to be passed on to one thread at a time to allow for execution. A good analogy I read was a rubber duck in an office meeting. The worker ( our thread ) that is first to talk ( execute ) receieves the duck from the boss and says
his peace, then passes the duck back to the boss where the boss then hands it out to the next person to talk. Only the person with the duck can talk. I followed this analogy to structure my threads throughout all of my functions. 
These critical sections are important to the code as they keep the correct execution pattern of threads in the pool.
	Our condition variable is initialized with NULL in create_threadpool. In dispact, we use cond_signal to wake up at least one condition, this way we don't wake up none and don't wake them all up at once. This allows for
the synchronization of 1 after another execution. In destroy_threadpool we use broadcast so this way before we destroy our threadpool, we make sure to wake up ALL threads this way none get lost in the void. After waking them up we 
join them together to make it so the current process cannot be closed until all threads are completed. In thread_main we use cond_wait. Since we won't always have a thread in standy, we use this condition to wait for a thread to 
wake up, and when woken up, processor is notified and the lock is automatiaclly released. Makes it conveniet for when we don't have threads automatically passed in all at once. 
	
