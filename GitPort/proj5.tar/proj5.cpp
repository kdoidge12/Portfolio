#include <iostream>
#include <cstring>
#include "passserver.h"
#include <vector>
#include <termios.h>
#include <unistd.h>

using namespace std;

void Menu();


int main()
{
	size_t y;
	char choice;
	cout<<"Enter preferred hash  table capacity: "<<endl;
	cin>>y;
	PassServer DaHash(y);
	
	Menu();
	cin>>choice;
	while(choice != 'x')
	{
		
		switch(choice)
		{
			case 'l':{
			string file;
			cout<<"Enter password file name to load from: "<<endl;
			cin>>file;
			DaHash.load(file.c_str());
	
			break;}
		
			case 'a':
			{
			
			string user;
			string pass;
			cout<<"Enter username: "<<endl;
			cin >> user;
			cout<<"\nEnter password: "<<endl;
			cin>> pass;
			std::pair<string,string>temp(user,pass);
			DaHash.addUser(temp);
			break;
			}
			case 'r':
			{
			string user;
			cout<< "Enter usename: ";
			cin >> user;
			if(!DaHash.removeUser(user))
				cout << "User does not exist.";
			break; 
			}
			case 'c':
			{
			string user;
			string pass;
			string newpass;
			cout<<"Enter username: "<<endl;
			cin >> user;
			cout<<"\nEnter password: "<<endl;
			cin >> pass;
			cout<<"\nEnter new password: " << endl;
			cin >> newpass;
			
			std::pair<string,string>temp(user,pass);
			DaHash.changePassword(temp,newpass);	
			break; 
			}
			case 'f':
			{
			string user;
			cout<< "Enter username: " << endl;
			cin >> user;
			if(!DaHash.find(user))
			{
				cout << "User does not exist.";
			}
			else
				cout << "User '" << user << "' found";
			
			break; 
			}
			case 'd':{
			DaHash.dump();
			break;} 
			
			case 's':{
				cout << "The size is: " << DaHash.size();
				break;
			}
			
			
			case 'w':
				{
					string file;
					cout << "Enter password file name to write to: ";
					cin >> file;
					DaHash.write_to_file(file.c_str());
				}
			cout<<"write to password "<<endl;
			break; 
			
			case 'x':
			cout<<"exit program"<<endl;
			break;
			
			default:
				cout << "*****Error: Invalid entry. Try Again.";
		
		}
		
		Menu();
		cin>> choice;
	}
	
	
};

void Menu()
{
  cout << "\n\n";
  cout << "l - Load From File" << endl;
  cout << "a - Add User" << endl;
  cout << "r - Remove User" << endl;
  cout << "c - Change User Password" << endl;
  cout << "f - Find User" << endl;
  cout << "d - Dump HashTable" << endl;
  cout << "s - HashTable Size" << endl;
  cout << "w - Write to Password File" << endl;
  cout << "x - Exit program" << endl;
  cout << "\nEnter choice : ";
}
