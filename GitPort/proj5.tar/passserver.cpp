//Kristopher Doidge

#include "passserver.h"
#include <crypt.h>
#include <iostream>
#include <utility>
#include <unistd.h>
#include <crypt.h>
#include <string>
#include <cstring>

using namespace std;

PassServer::PassServer(size_t size)
{
 server = new HashTable<string,string>(size);
 cout << "Table Capacity : " << server->getprimebelow(size);
}

PassServer::~PassServer()
{
	delete server;
}

bool PassServer::load(const char *filename)
{
	
	return server->load(filename);
}

bool PassServer::addUser(std::pair<string,string>& kv)
{
	if(server->contains(kv.first))
	{
		removeUser(kv.first);
	}
	kv.second = encrypt(kv.second);
	return server->insert(kv);
}

bool PassServer::addUser(std::pair<string, string> && kv)
{
	if(server->contains(kv.first))
	{
		removeUser(kv.first);
	}
	kv.second = encrypt(kv.second);
	return server->insert(kv);	
}

bool PassServer::changePassword(const pair<string, string> &p, const string & newpassword)
{
	std::pair<string,string> temp(p.first,p.second);
	string newenc = newpassword;
	newenc = encrypt(newenc);
	temp.second = encrypt(temp.second);
	if(!server->contains(temp.first))
	{
		cout << "Username does not exist.";
		return false;
	}
	if(!server->match(temp))
	{
		cout << "Password does not match.";
		return false;
	}
	removeUser(temp.first);
	temp.second = newenc;
	addUser(temp);
	return true;
	
		
}

bool PassServer::removeUser(const string & k)
{
	return server->remove(k);
}

bool PassServer::find(const string &user)
{
	return server->contains(user);
}

void PassServer::dump()
{
	server->dump();
}

size_t PassServer::size()
{
	return server->size();	
}

bool PassServer::write_to_file(const char *filename)
{
	return server->write_to_file(filename);
}
string PassServer::encrypt(const string &str)
{
	char salt[] = "$1$#######";
	string enc = str;
	char *password = new char[100];
	strcpy(password, crypt(enc.c_str(), salt));
	return password;
}


