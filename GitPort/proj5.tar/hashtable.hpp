//Kristopher Doidge

// returns largest prime number <= n or zero if input is too large
// This is likely to be more efficient than prime_above(), because
// it only needs a vector of size n

template <typename K, typename V>
HashTable<K,V>::HashTable(size_t size)
{
	size = prime_below(size);
	hash.resize(size);
	count = 0;
}

template <typename K, typename V>
HashTable<K,V>::~HashTable()
{
	clear();
}

template <typename K,typename V>
bool HashTable<K,V>::contains(const K & k)
{ 
	size_t index = myhash(k);
	
	typename list<pair<K, V> >::iterator iter;
	for(iter = hash[index].begin(); iter!=hash[index].end();iter++)
	{
		if(iter->first == k)
			return true;
	}
	return false;
}

template <typename K,typename V>
bool HashTable<K,V>::match(const std::pair<K, V> &kv)
{
	
	
	if(contains(kv.first))
	{
		size_t index = myhash(kv.first);
		typename list<pair<K, V> >::iterator iter = find(hash[index].begin(), hash[index].end(), kv);
		if(hash[index].end()==iter)
		{
			return false;
		}
		else
			return true;
	}
	else
		return false; 
}

template <typename K,typename V>
bool HashTable<K,V>::insert(const std::pair<K, V> & kv)
{
	if(!match(kv))
	{
		if(size() >= hash.size())
			rehash();
		
		size_t index = myhash(kv.first);

		hash[index].push_back(kv);
		count++;
		return true;
	}
	else 
		return false;
}

template <typename K,typename V>
bool HashTable<K,V>::insert (std::pair<K,V> && kv)
{ 
	if(!match(kv))
	{
	if(size() >= hash.size())
			rehash();
		
		size_t index = myhash(kv.first);
		hash[index].push_back(std::move(kv));
		count++;
		return true;
	}
	else 
		return false;	
}

template <typename K,typename V>
bool HashTable<K,V>::remove(const K &k)
{
	size_t in;
	in = myhash(k);
	if(hash[in].empty())
	{
	 return false;
	}
	else
	{
		typename list<pair<K, V> >::iterator iter;
		for(iter = hash[in].begin();iter !=hash[in].end();iter++)
		{

			if(iter->first == k)
			{
				hash[in].erase(iter);
				count--;
				return true;
			}
		}
	return false;
	 
	}
}

template <typename K,typename V>
void HashTable<K,V>::clear()
{
	makeEmpty();
}

template <typename K,typename V>
size_t HashTable<K,V>::myhash(const K &k)
{
 	size_t index;
	string examp = k;
	int sum = 0;
	for(int i=0;i<examp.length();i++)
	{
		sum+= examp[i];
	}
	index = sum % hash.size();
	return index;
	

}

template <typename K,typename V>
void HashTable<K,V>::dump()
{
	
	for(int c=0; c< hash.size(); c++)
	{
		cout << "v["<<c<<"] = ";
		if(!hash[c].empty())
		{
			int z = 0;
			typename list<pair<K, V> >::iterator iter;
			for(iter = hash[c].begin();iter !=hash[c].end();++iter)
			{
				if(z!=0)
					cout << ':';
				cout << iter->first << ' ' << iter->second ;
				z++;
			}
		}
		cout << endl;
	}
}

template <typename K, typename V>
size_t HashTable<K, V>::size()
{
	return count;
}

template <typename K, typename V>
void HashTable<K, V>::makeEmpty()
{
 	for(int i=0;i<hash.size();i++)
 	{
	 hash[i].clear();
 	}
 	hash.clear();
	 count=0;	
}

template <typename K, typename V>
void HashTable<K, V>::rehash()
{
	size_t re= prime_below(hash.size()*2);
	HashTable<K,V>temp(re);
	//hash.resize(re);
	typename list<pair<K, V> >::iterator itr;
	for(int i = 0; i < hash.size();i++)
	{
		for(itr = hash[i].begin();itr!=hash[i].end();itr++)
		{
			std::pair<K,V>old(itr->first,itr->second);
			temp.insert(old);						
		}
	}
	hash.resize(re);
	hash = temp.hash;
}

template <typename K, typename V>
unsigned long HashTable<K, V>::prime_below (unsigned long n)
{
  if (n > max_prime)
    {
      std::cerr << "** input too large for prime_below()\n";
      return 0;
    }
  if (n == max_prime)
    {
      return max_prime;
    }
  if (n <= 1)
    {
		std::cerr << "** input too small \n";
      return 0;
    }

  // now: 2 <= n < max_prime
  std::vector <unsigned long> v (n+1);
  setPrimes(v);
  while (n > 2)
    {
      if (v[n] == 1)
	return n;
      --n;
    }

  return 2;
}

template <typename K,typename V>
bool HashTable<K,V>::load(const char *filename)
{
	string a,b;
	ifstream myfile(filename);
	if(myfile.is_open())
	{
		while(myfile>>a>>b)
		{
			std::pair<string,string> foo(a,b);
			insert(foo);
		}	
	} 
}

template <typename K,typename V>
bool HashTable<K,V>::write_to_file(const char *filename)
{
	ofstream outfile;
	outfile.open(filename);
	
	typename list<pair<K,V> >::iterator itr;
	for(int i=0;i < hash.size();i++)
	{
		if(!hash[i].empty())
		{
			for(itr=hash[i].begin();itr!=hash[i].end();itr++)
				outfile << itr->first << ' ' << itr->second << endl;
		}
	}
	outfile.close();
}


//Sets all prime number indexes to 1. Called by method prime_below(n) 
template <typename K, typename V>
void HashTable<K, V>::setPrimes(std::vector<unsigned long>& vprimes)
{
  int i = 0;
  int j = 0;

  vprimes[0] = 0;
  vprimes[1] = 0;
  int n = vprimes.capacity();

  for (i = 2; i < n; ++i)
    vprimes[i] = 1;

  for( i = 2; i*i < n; ++i)
    {
      if (vprimes[i] == 1)
        for(j = i + i ; j < n; j += i)
          vprimes[j] = 0;
    }
}

template <typename K, typename V>
unsigned long HashTable<K, V>::getprimebelow(unsigned long size)
{
	size = prime_below(size);
	return size;
}













